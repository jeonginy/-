package model;

import java.util.ArrayList;
import java.util.List;

public class UserValidator {
	public List<String> checkUserName(String userName) {
		List<String> errors = new ArrayList<>();
		if (userName == null || userName.trim().length() == 0) {
			errors.add("Enter your nickname");
		}
		if (userName.contains(" ")) {
			errors.add("Blanks not valid");
		}
		if (!isLowerChars(userName)) {
			errors.add("Only Lowercase");
		}
		if (userName.length() > 45) {
			errors.add("Limited to 45 words");
		}
		return errors;
	}
	
	private boolean isLowerChars(String input) {
		for (int i = 0; i < input.length(); i++) {
			char c = input.charAt(i);
			if (c < 'a' || c > 'z') {
				return false;
			}
		}
		return true;
	}
}
